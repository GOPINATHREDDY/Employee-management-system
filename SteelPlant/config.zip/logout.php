<?php
	require 'config/helpers.php';
	session_start();
	logout();
?>